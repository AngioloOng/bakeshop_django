document.getElementById('loginForm').addEventListener('submit', function(event) {



    }

